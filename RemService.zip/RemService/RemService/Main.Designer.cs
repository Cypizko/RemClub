﻿namespace RemService
{
    partial class RemService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TabPage tabPage1;
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            buttonFind = new Button();
            textBoxFind = new TextBox();
            label1 = new Label();
            loadBtn = new Button();
            clearBtn = new Button();
            saveBtn = new Button();
            sortBtn = new Button();
            delBtn = new Button();
            redBtn = new Button();
            addBtn = new Button();
            labelWorkPrice = new Label();
            labelMaster = new Label();
            labelDate = new Label();
            labelDetailPrice = new Label();
            labelModel = new Label();
            masterTextBox = new TextBox();
            dateTextBox = new TextBox();
            workPriceTextBox = new TextBox();
            detailPriceTextBox = new TextBox();
            modelTextBox = new TextBox();
            invoicesDGV = new DataGridView();
            numberColumn = new DataGridViewTextBoxColumn();
            modelColumn = new DataGridViewTextBoxColumn();
            detailPriceColumn = new DataGridViewTextBoxColumn();
            workPriceColumn = new DataGridViewTextBoxColumn();
            fullPriceColumn = new DataGridViewTextBoxColumn();
            dateColumn = new DataGridViewTextBoxColumn();
            masterColumn = new DataGridViewTextBoxColumn();
            tabControl1 = new TabControl();
            tabPage2 = new TabPage();
            secondDateCalendar = new DateTimePicker();
            firstDateCalendar = new DateTimePicker();
            resultDateTextBox = new TextBox();
            modelsComboBox = new ComboBox();
            findDGV = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn7 = new DataGridViewTextBoxColumn();
            findBtn = new Button();
            dateRBtn = new RadioButton();
            masterRBtn = new RadioButton();
            highPriceRBtn = new RadioButton();
            modelRBtn = new RadioButton();
            masterComboBox = new ComboBox();
            tabPage1 = new TabPage();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)invoicesDGV).BeginInit();
            tabControl1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)findDGV).BeginInit();
            SuspendLayout();
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.GradientInactiveCaption;
            tabPage1.Controls.Add(buttonFind);
            tabPage1.Controls.Add(textBoxFind);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(loadBtn);
            tabPage1.Controls.Add(clearBtn);
            tabPage1.Controls.Add(saveBtn);
            tabPage1.Controls.Add(sortBtn);
            tabPage1.Controls.Add(delBtn);
            tabPage1.Controls.Add(redBtn);
            tabPage1.Controls.Add(addBtn);
            tabPage1.Controls.Add(labelWorkPrice);
            tabPage1.Controls.Add(labelMaster);
            tabPage1.Controls.Add(labelDate);
            tabPage1.Controls.Add(labelDetailPrice);
            tabPage1.Controls.Add(labelModel);
            tabPage1.Controls.Add(masterTextBox);
            tabPage1.Controls.Add(dateTextBox);
            tabPage1.Controls.Add(workPriceTextBox);
            tabPage1.Controls.Add(detailPriceTextBox);
            tabPage1.Controls.Add(modelTextBox);
            tabPage1.Controls.Add(invoicesDGV);
            tabPage1.Location = new Point(4, 32);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1115, 592);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Особистий кабінет";
            // 
            // buttonFind
            // 
            buttonFind.BackColor = SystemColors.ActiveCaption;
            buttonFind.FlatStyle = FlatStyle.Popup;
            buttonFind.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            buttonFind.Location = new Point(984, 94);
            buttonFind.Name = "buttonFind";
            buttonFind.Size = new Size(113, 29);
            buttonFind.TabIndex = 21;
            buttonFind.Text = "Знайти";
            buttonFind.UseVisualStyleBackColor = false;
            buttonFind.Click += buttonFind_Click_1;
            // 
            // textBoxFind
            // 
            textBoxFind.BackColor = SystemColors.GradientActiveCaption;
            textBoxFind.BorderStyle = BorderStyle.FixedSingle;
            textBoxFind.Cursor = Cursors.IBeam;
            textBoxFind.Location = new Point(989, 47);
            textBoxFind.Name = "textBoxFind";
            textBoxFind.Size = new Size(99, 27);
            textBoxFind.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(1003, 14);
            label1.Name = "label1";
            label1.Size = new Size(63, 20);
            label1.TabIndex = 19;
            label1.Text = "Пошук:";
            // 
            // loadBtn
            // 
            loadBtn.BackColor = SystemColors.ActiveCaption;
            loadBtn.FlatStyle = FlatStyle.Popup;
            loadBtn.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            loadBtn.Location = new Point(769, 534);
            loadBtn.Name = "loadBtn";
            loadBtn.Size = new Size(252, 29);
            loadBtn.TabIndex = 18;
            loadBtn.Text = "Завантажити х XML";
            loadBtn.UseVisualStyleBackColor = false;
            loadBtn.Click += loadBtn_Click;
            // 
            // clearBtn
            // 
            clearBtn.BackColor = SystemColors.ActiveCaption;
            clearBtn.FlatStyle = FlatStyle.Popup;
            clearBtn.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            clearBtn.Location = new Point(428, 534);
            clearBtn.Name = "clearBtn";
            clearBtn.Size = new Size(252, 29);
            clearBtn.TabIndex = 17;
            clearBtn.Text = "Очистити";
            clearBtn.UseVisualStyleBackColor = false;
            clearBtn.Click += clearBtn_Click;
            // 
            // saveBtn
            // 
            saveBtn.BackColor = SystemColors.ActiveCaption;
            saveBtn.FlatStyle = FlatStyle.Popup;
            saveBtn.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            saveBtn.Location = new Point(80, 534);
            saveBtn.Name = "saveBtn";
            saveBtn.Size = new Size(252, 29);
            saveBtn.TabIndex = 16;
            saveBtn.Text = "Зберегти як XML";
            saveBtn.UseVisualStyleBackColor = false;
            saveBtn.Click += saveBtn_Click_1;
            // 
            // sortBtn
            // 
            sortBtn.BackColor = SystemColors.ActiveCaption;
            sortBtn.FlatStyle = FlatStyle.Popup;
            sortBtn.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            sortBtn.Location = new Point(742, 94);
            sortBtn.Name = "sortBtn";
            sortBtn.Size = new Size(207, 29);
            sortBtn.TabIndex = 15;
            sortBtn.Text = "Сортувати";
            sortBtn.UseVisualStyleBackColor = false;
            sortBtn.Click += sortBtn_Click;
            // 
            // delBtn
            // 
            delBtn.BackColor = SystemColors.ActiveCaption;
            delBtn.FlatStyle = FlatStyle.Popup;
            delBtn.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            delBtn.Location = new Point(497, 94);
            delBtn.Name = "delBtn";
            delBtn.Size = new Size(207, 29);
            delBtn.TabIndex = 14;
            delBtn.Text = "Видалити";
            delBtn.UseVisualStyleBackColor = false;
            delBtn.Click += delBtn_Click;
            // 
            // redBtn
            // 
            redBtn.BackColor = SystemColors.ActiveCaption;
            redBtn.FlatStyle = FlatStyle.Popup;
            redBtn.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            redBtn.Location = new Point(257, 94);
            redBtn.Name = "redBtn";
            redBtn.Size = new Size(207, 29);
            redBtn.TabIndex = 13;
            redBtn.Text = "Редагувати";
            redBtn.UseVisualStyleBackColor = false;
            redBtn.Click += redBtn_Click;
            // 
            // addBtn
            // 
            addBtn.BackColor = SystemColors.ActiveCaption;
            addBtn.FlatStyle = FlatStyle.Popup;
            addBtn.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            addBtn.Location = new Point(8, 94);
            addBtn.Name = "addBtn";
            addBtn.Size = new Size(207, 29);
            addBtn.TabIndex = 12;
            addBtn.Text = "Додати";
            addBtn.UseVisualStyleBackColor = false;
            addBtn.Click += addBtn_Click;
            // 
            // labelWorkPrice
            // 
            labelWorkPrice.AutoSize = true;
            labelWorkPrice.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            labelWorkPrice.Location = new Point(434, 14);
            labelWorkPrice.Name = "labelWorkPrice";
            labelWorkPrice.Size = new Size(133, 20);
            labelWorkPrice.TabIndex = 11;
            labelWorkPrice.Text = "Вартість роботи:";
            // 
            // labelMaster
            // 
            labelMaster.AutoSize = true;
            labelMaster.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            labelMaster.Location = new Point(779, 14);
            labelMaster.Name = "labelMaster";
            labelMaster.Size = new Size(83, 20);
            labelMaster.TabIndex = 10;
            labelMaster.Text = "Майстер:";
            // 
            // labelDate
            // 
            labelDate.AutoSize = true;
            labelDate.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            labelDate.Location = new Point(602, 14);
            labelDate.Name = "labelDate";
            labelDate.Size = new Size(120, 20);
            labelDate.TabIndex = 9;
            labelDate.Text = "Дата ремонту:";
            // 
            // labelDetailPrice
            // 
            labelDetailPrice.AutoSize = true;
            labelDetailPrice.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            labelDetailPrice.Location = new Point(257, 14);
            labelDetailPrice.Name = "labelDetailPrice";
            labelDetailPrice.Size = new Size(140, 20);
            labelDetailPrice.TabIndex = 7;
            labelDetailPrice.Text = "Вартість деталей:";
            // 
            // labelModel
            // 
            labelModel.AutoSize = true;
            labelModel.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            labelModel.Location = new Point(8, 14);
            labelModel.Name = "labelModel";
            labelModel.Size = new Size(69, 20);
            labelModel.TabIndex = 6;
            labelModel.Text = "Прилад:";
            // 
            // masterTextBox
            // 
            masterTextBox.BackColor = SystemColors.GradientActiveCaption;
            masterTextBox.BorderStyle = BorderStyle.FixedSingle;
            masterTextBox.Cursor = Cursors.IBeam;
            masterTextBox.Location = new Point(779, 47);
            masterTextBox.Name = "masterTextBox";
            masterTextBox.Size = new Size(170, 27);
            masterTextBox.TabIndex = 5;
            // 
            // dateTextBox
            // 
            dateTextBox.BackColor = SystemColors.GradientActiveCaption;
            dateTextBox.BorderStyle = BorderStyle.FixedSingle;
            dateTextBox.Cursor = Cursors.IBeam;
            dateTextBox.Location = new Point(602, 47);
            dateTextBox.Name = "dateTextBox";
            dateTextBox.Size = new Size(125, 27);
            dateTextBox.TabIndex = 4;
            // 
            // workPriceTextBox
            // 
            workPriceTextBox.BackColor = SystemColors.GradientActiveCaption;
            workPriceTextBox.BorderStyle = BorderStyle.FixedSingle;
            workPriceTextBox.Cursor = Cursors.IBeam;
            workPriceTextBox.Location = new Point(434, 47);
            workPriceTextBox.Name = "workPriceTextBox";
            workPriceTextBox.Size = new Size(133, 27);
            workPriceTextBox.TabIndex = 3;
            // 
            // detailPriceTextBox
            // 
            detailPriceTextBox.BackColor = SystemColors.GradientActiveCaption;
            detailPriceTextBox.BorderStyle = BorderStyle.FixedSingle;
            detailPriceTextBox.Cursor = Cursors.IBeam;
            detailPriceTextBox.Location = new Point(257, 47);
            detailPriceTextBox.Name = "detailPriceTextBox";
            detailPriceTextBox.Size = new Size(140, 27);
            detailPriceTextBox.TabIndex = 2;
            // 
            // modelTextBox
            // 
            modelTextBox.BackColor = SystemColors.GradientActiveCaption;
            modelTextBox.BorderStyle = BorderStyle.FixedSingle;
            modelTextBox.Cursor = Cursors.IBeam;
            modelTextBox.Location = new Point(6, 47);
            modelTextBox.Name = "modelTextBox";
            modelTextBox.Size = new Size(209, 27);
            modelTextBox.TabIndex = 1;
            // 
            // invoicesDGV
            // 
            invoicesDGV.BackgroundColor = SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            invoicesDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            invoicesDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            invoicesDGV.Columns.AddRange(new DataGridViewColumn[] { numberColumn, modelColumn, detailPriceColumn, workPriceColumn, fullPriceColumn, dateColumn, masterColumn });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            invoicesDGV.DefaultCellStyle = dataGridViewCellStyle2;
            invoicesDGV.Location = new Point(8, 140);
            invoicesDGV.Name = "invoicesDGV";
            invoicesDGV.RowHeadersWidth = 51;
            invoicesDGV.RowTemplate.Height = 29;
            invoicesDGV.Size = new Size(1099, 361);
            invoicesDGV.TabIndex = 0;
            // 
            // numberColumn
            // 
            numberColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            numberColumn.HeaderText = "№";
            numberColumn.MinimumWidth = 6;
            numberColumn.Name = "numberColumn";
            numberColumn.Width = 70;
            // 
            // modelColumn
            // 
            modelColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            modelColumn.HeaderText = "Прилад";
            modelColumn.MinimumWidth = 6;
            modelColumn.Name = "modelColumn";
            // 
            // detailPriceColumn
            // 
            detailPriceColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            detailPriceColumn.HeaderText = "Вартість деталей";
            detailPriceColumn.MinimumWidth = 6;
            detailPriceColumn.Name = "detailPriceColumn";
            // 
            // workPriceColumn
            // 
            workPriceColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            workPriceColumn.HeaderText = "Вартість роботи";
            workPriceColumn.MinimumWidth = 6;
            workPriceColumn.Name = "workPriceColumn";
            // 
            // fullPriceColumn
            // 
            fullPriceColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            fullPriceColumn.HeaderText = "Загальна вартість";
            fullPriceColumn.MinimumWidth = 6;
            fullPriceColumn.Name = "fullPriceColumn";
            // 
            // dateColumn
            // 
            dateColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dateColumn.HeaderText = "Дата ремонту";
            dateColumn.MinimumWidth = 6;
            dateColumn.Name = "dateColumn";
            // 
            // masterColumn
            // 
            masterColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            masterColumn.HeaderText = "Майстер";
            masterColumn.MinimumWidth = 6;
            masterColumn.Name = "masterColumn";
            // 
            // tabControl1
            // 
            tabControl1.Appearance = TabAppearance.FlatButtons;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(0, 12);
            tabControl1.Multiline = true;
            tabControl1.Name = "tabControl1";
            tabControl1.RightToLeft = RightToLeft.No;
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1123, 628);
            tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = SystemColors.GradientInactiveCaption;
            tabPage2.Controls.Add(secondDateCalendar);
            tabPage2.Controls.Add(firstDateCalendar);
            tabPage2.Controls.Add(resultDateTextBox);
            tabPage2.Controls.Add(modelsComboBox);
            tabPage2.Controls.Add(findDGV);
            tabPage2.Controls.Add(findBtn);
            tabPage2.Controls.Add(dateRBtn);
            tabPage2.Controls.Add(masterRBtn);
            tabPage2.Controls.Add(highPriceRBtn);
            tabPage2.Controls.Add(modelRBtn);
            tabPage2.Controls.Add(masterComboBox);
            tabPage2.Location = new Point(4, 32);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1115, 592);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Формування відомостей";
            // 
            // secondDateCalendar
            // 
            secondDateCalendar.Location = new Point(467, 180);
            secondDateCalendar.Name = "secondDateCalendar";
            secondDateCalendar.Size = new Size(250, 27);
            secondDateCalendar.TabIndex = 16;
            secondDateCalendar.Visible = false;
            // 
            // firstDateCalendar
            // 
            firstDateCalendar.Location = new Point(467, 137);
            firstDateCalendar.Name = "firstDateCalendar";
            firstDateCalendar.Size = new Size(250, 27);
            firstDateCalendar.TabIndex = 15;
            firstDateCalendar.Visible = false;
            // 
            // resultDateTextBox
            // 
            resultDateTextBox.BackColor = SystemColors.InactiveCaption;
            resultDateTextBox.BorderStyle = BorderStyle.FixedSingle;
            resultDateTextBox.Location = new Point(809, 180);
            resultDateTextBox.Name = "resultDateTextBox";
            resultDateTextBox.Size = new Size(125, 27);
            resultDateTextBox.TabIndex = 12;
            resultDateTextBox.Visible = false;
            // 
            // modelsComboBox
            // 
            modelsComboBox.BackColor = SystemColors.GradientActiveCaption;
            modelsComboBox.FormattingEnabled = true;
            modelsComboBox.Location = new Point(482, 29);
            modelsComboBox.Name = "modelsComboBox";
            modelsComboBox.Size = new Size(151, 28);
            modelsComboBox.TabIndex = 11;
            modelsComboBox.Visible = false;
            // 
            // findDGV
            // 
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            findDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            findDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            findDGV.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7 });
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            findDGV.DefaultCellStyle = dataGridViewCellStyle4;
            findDGV.Location = new Point(8, 240);
            findDGV.Name = "findDGV";
            findDGV.RowHeadersWidth = 51;
            findDGV.RowTemplate.Height = 29;
            findDGV.Size = new Size(1099, 361);
            findDGV.TabIndex = 10;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn1.HeaderText = "№";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.Width = 70;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn2.HeaderText = "Прилад";
            dataGridViewTextBoxColumn2.MinimumWidth = 6;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn3.HeaderText = "Вартість деталей";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn4.HeaderText = "Вартість роботи";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn5.HeaderText = "Загальна вартість";
            dataGridViewTextBoxColumn5.MinimumWidth = 6;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn6.HeaderText = "Дата ремонту";
            dataGridViewTextBoxColumn6.MinimumWidth = 6;
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn7.HeaderText = "Майстер";
            dataGridViewTextBoxColumn7.MinimumWidth = 6;
            dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // findBtn
            // 
            findBtn.BackColor = SystemColors.ActiveCaption;
            findBtn.FlatStyle = FlatStyle.Popup;
            findBtn.Location = new Point(946, 102);
            findBtn.Name = "findBtn";
            findBtn.Size = new Size(135, 29);
            findBtn.TabIndex = 9;
            findBtn.Text = "Сформувати";
            findBtn.UseVisualStyleBackColor = false;
            findBtn.Click += findBtn_Click;
            // 
            // dateRBtn
            // 
            dateRBtn.AutoSize = true;
            dateRBtn.Location = new Point(23, 170);
            dateRBtn.Name = "dateRBtn";
            dateRBtn.Size = new Size(324, 44);
            dateRBtn.TabIndex = 4;
            dateRBtn.TabStop = true;
            dateRBtn.Text = "Обчислення загальної вартості замінених\r\n деталей за певний період";
            dateRBtn.UseVisualStyleBackColor = true;
            dateRBtn.CheckedChanged += dateRBtn_CheckedChanged;
            // 
            // masterRBtn
            // 
            masterRBtn.AutoSize = true;
            masterRBtn.Location = new Point(23, 120);
            masterRBtn.Name = "masterRBtn";
            masterRBtn.Size = new Size(311, 44);
            masterRBtn.TabIndex = 3;
            masterRBtn.TabStop = true;
            masterRBtn.Text = "Формування відомостей про всі роботи\r\n заданого майстра";
            masterRBtn.UseVisualStyleBackColor = true;
            masterRBtn.CheckedChanged += masterRBtn_CheckedChanged;
            // 
            // highPriceRBtn
            // 
            highPriceRBtn.AutoSize = true;
            highPriceRBtn.Location = new Point(23, 70);
            highPriceRBtn.Name = "highPriceRBtn";
            highPriceRBtn.Size = new Size(277, 44);
            highPriceRBtn.TabIndex = 2;
            highPriceRBtn.TabStop = true;
            highPriceRBtn.Text = "Формування відомостей про п'ять\r\n найдорожчих виконаних ремонтів";
            highPriceRBtn.UseVisualStyleBackColor = true;
            highPriceRBtn.CheckedChanged += highPriceRBtn_CheckedChanged;
            // 
            // modelRBtn
            // 
            modelRBtn.AutoSize = true;
            modelRBtn.Location = new Point(23, 20);
            modelRBtn.Name = "modelRBtn";
            modelRBtn.Size = new Size(289, 44);
            modelRBtn.TabIndex = 1;
            modelRBtn.TabStop = true;
            modelRBtn.Text = "Формування відомостей про ремонт\r\n за певною моделлю приладу";
            modelRBtn.UseVisualStyleBackColor = true;
            modelRBtn.CheckedChanged += modelRBtn_CheckedChanged;
            // 
            // masterComboBox
            // 
            masterComboBox.BackColor = SystemColors.GradientActiveCaption;
            masterComboBox.FormattingEnabled = true;
            masterComboBox.Location = new Point(482, 129);
            masterComboBox.Name = "masterComboBox";
            masterComboBox.Size = new Size(151, 28);
            masterComboBox.TabIndex = 0;
            masterComboBox.Visible = false;
            // 
            // RemService
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(1126, 644);
            Controls.Add(tabControl1);
            Name = "RemService";
            Text = "Main";
            FormClosed += Main_FormClosed;
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)invoicesDGV).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)findDGV).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private DataGridView invoicesDGV;
        private Label labelMaster;
        private Label labelDate;
        private Label labelDetailPrice;
        private Label labelModel;
        private TextBox masterTextBox;
        private TextBox dateTextBox;
        private TextBox workPriceTextBox;
        private TextBox detailPriceTextBox;
        private TextBox modelTextBox;
        private Label labelWorkPrice;
        private Button addBtn;
        private Button redBtn;
        private Button delBtn;
        private Button loadBtn;
        private Button clearBtn;
        private Button saveBtn;
        private Button sortBtn;
        private DataGridViewTextBoxColumn numberColumn;
        private DataGridViewTextBoxColumn modelColumn;
        private DataGridViewTextBoxColumn detailPriceColumn;
        private DataGridViewTextBoxColumn workPriceColumn;
        private DataGridViewTextBoxColumn fullPriceColumn;
        private DataGridViewTextBoxColumn dateColumn;
        private DataGridViewTextBoxColumn masterColumn;
        private RadioButton dateRBtn;
        private RadioButton masterRBtn;
        private RadioButton highPriceRBtn;
        private RadioButton modelRBtn;
        private ComboBox masterComboBox;
        private Button findBtn;
        private DataGridView findDGV;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private ComboBox modelsComboBox;
        private TextBox resultDateTextBox;
        private DateTimePicker firstDateCalendar;
        private DateTimePicker secondDateCalendar;
        private Label label1;
        private Button buttonFind;
        private TextBox textBoxFind;
    }
}